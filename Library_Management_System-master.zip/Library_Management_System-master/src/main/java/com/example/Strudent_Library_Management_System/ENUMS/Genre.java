package com.example.Strudent_Library_Management_System.ENUMS;

public enum Genre {
    FICTIONAL,
    SELF_HELP,
    PHILOSOPHY,
    INSPIRATIONAL,
    SPIRITUAL,
    HORROR,
    DRAMA,
    MYSTERY,
    KAMSUTRA

}
