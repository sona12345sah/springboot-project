package com.example.Strudent_Library_Management_System.ENUMS;

public enum TransactionStatus {
    PENDING,
    FAILED,
    SUCCESS
}
