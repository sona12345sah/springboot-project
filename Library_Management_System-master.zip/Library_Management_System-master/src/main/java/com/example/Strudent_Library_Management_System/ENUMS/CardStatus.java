package com.example.Strudent_Library_Management_System.ENUMS;

public enum CardStatus {
    ACTIVATED,
    DEACTIVATED,
    BLOCKED,
    EXPIRED
}