package com.example.Strudent_Library_Management_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrudentLibraryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrudentLibraryManagementSystemApplication.class, args);
	}

}
